package com.example.org.service;

import com.example.org.bean.Exam;
import com.example.org.bean.Student;
import com.example.org.dao.ExamsDao;

import java.util.List;

public class ExamService {
    ExamsDao dao = new ExamsDao();
    public boolean addExam(Exam exam) {
        return dao.addExam(exam);
    }

    public List<Exam> getAllExams() {
        return dao.getAllExams();
    }

    public Exam getExamId(int id) {
        return dao.getExamById(id);
    }

    public boolean updateExam(Exam exam){return dao.updateExam(exam);}

    public boolean deleteExam(Exam exam){return dao.deleteExam(exam);}
}
