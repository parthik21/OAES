package com.example.org.service;

import com.example.org.bean.Test;
import com.example.org.dao.TestDAO;

import java.util.List;

public class TestService {
    TestDAO dao = new TestDAO();
    public boolean addExam(Test test) {
        return dao.addTest(test);
    }

    public List<Test> getAllTests() {
        return dao.getAllTests();
    }

    public Test getTestById(int id) {
        return dao.getTestById(id);
    }

    public boolean updateTest(Test test){return dao.updateTest(test);}

    public boolean deleteTest(Test test){return dao.deleteTest(test);}
}
