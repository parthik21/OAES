package com.example.org.service;

import com.example.org.bean.Student;
import com.example.org.dao.StudentDAO;

import java.util.List;

public class StudentService {
    StudentDAO dao = new StudentDAO();
    public boolean addStudent(Student student) {
        return dao.addStudent(student);
    }
    public List<Student> getAllStudents() {
        return dao.getAllStudents();
    }
    public Student getStudentById(int id) {
        return dao.getStudentById(id);
    }
    public boolean updateStudent(Student student){return dao.updateStudent(student);}
    public boolean deleteStudent(Student student){return dao.deleteStudent(student);}
}
