package com.example.org.service;

import com.example.org.bean.Evaluation;
import com.example.org.dao.EvaluationDAO;

import java.util.List;

public class EvaluationService {

    EvaluationDAO dao = new EvaluationDAO();
    public boolean addExam(Evaluation exam) {
        return dao.addEvaluation(exam);
    }

    public List<Evaluation> getAllExams(int student_id) {
        return dao.getAllEvaluations(student_id);
    }

    public Evaluation getEvaluationById(int id) {
        return dao.getEvaluationById(id);
    }

    public boolean updateEvaluation(Evaluation evaluation){return dao.updateEvaluation(evaluation);}

    public boolean deleteEvaluation(Evaluation evaluation){return dao.deleteEvaluation(evaluation);}

}
