package com.example.org.controller;

import com.example.org.bean.Exam;
import com.example.org.bean.Test;
import com.example.org.service.ExamService;
import com.example.org.service.TestService;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;


@Path("test")
public class TestsController {
    TestService service = new TestService();

    @GET
    @Path("/uploaddata")
    @Produces(MediaType.TEXT_PLAIN)
    public Response uploadTest(@QueryParam("exam_id") int exam_id,
                                   @QueryParam("answer_key") String answer_key,
                               @QueryParam("negative_marking") String negative_marking){

        Test test = new Test();
        test.setNegative_marking(negative_marking);
        test.setAnswerKey(answer_key);
        ExamService examService = new ExamService();
        Exam exam = examService.getExamId(exam_id);
        test.setExam(exam);

        boolean result = service.addExam(test);
        String n = new String("New Test Created!");
        if(!result)
            n = new String("Error Creating Test!");
        return Response.ok().entity(n).build();
    }

    @GET
    @Path("/get")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getTests(){
        List<Test> tests = service.getAllTests();
        return Response.ok().entity(tests).build();
    }

    @GET
    @Path("/getbyid")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getTestById(@QueryParam("id") int id){
        Test test = service.getTestById(id);
        System.out.println(test);
        return Response.ok().entity(test).build();
    }

    @GET
    @Path("/delete")
    @Produces(MediaType.TEXT_PLAIN)
    public Response deleteTest(@QueryParam("id") int id){
        Test test = service.getTestById(id);
        boolean result = service.deleteTest(test);
        String n = new String("test deleted!");
        if(!result)
            n = new String("Error deleting test!");
        return Response.ok().entity(n).build();
    }

}



