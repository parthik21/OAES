package com.example.org.controller;

import com.example.org.bean.Student;
import com.example.org.service.StudentService;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

@Path("student")
public class StudentController  {
    StudentService service = new StudentService();

    @GET
    @Path("/get")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getStudents(){
        List<Student> organisations = service.getAllStudents();
        System.out.println(organisations.size());
        return Response.ok().entity(organisations).build();
    }

    @GET
    @Path("/get_by_id")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getStudentById(@QueryParam("id") int id){
        Student student = service.getStudentById(id);
        return Response.ok().entity(student).build();
    }

    @GET
    @Path("/uploaddata")
    @Produces(MediaType.TEXT_PLAIN)
    public Response uploadStudent(@QueryParam("first_name") String first_name,
                             @QueryParam("middle_name") String middle_name,
                             @QueryParam("last_name") String last_name,
                             @QueryParam("email") String email,
                             @QueryParam("contact_number") String contact_number,
                             @QueryParam("enrollment_number") String enrollment_number,
                             @QueryParam("address") String address,
                             @QueryParam("username") String username,
                             @QueryParam("password") String password
                             ){

        System.out.println("here!");

        StudentService service = new StudentService();
        Student student = new Student();
        student.setFirst_name(first_name);
        student.setLast_name(last_name);
        student.setAddress(address);
        student.setContact_number(contact_number);
        student.setEnrollment_number(enrollment_number);
        student.setUsername(username);
        student.setPassword(password);
        student.setEmail(email);
        student.setMiddle_name(middle_name);

        System.out.println("here!");
        boolean result = service.addStudent(student);
        String n = new String("New Student Created!");
        if(!result)
            n = new String("Error Creating student!");
        return Response.ok().entity(n).build();
    }

    @GET
    @Path("/delete")
    @Produces(MediaType.TEXT_PLAIN)
    public Response deleteStudent(@QueryParam("id") int id){
        Student student = service.getStudentById(id);
        boolean result = service.deleteStudent(student);
        String n = new String("Student Deleted Successfully!");
        if(!result)
            n = new String("Student could not be deleted!");
        return Response.ok().entity(n).build();
    }
}
