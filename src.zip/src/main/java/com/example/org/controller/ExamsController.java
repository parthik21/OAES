package com.example.org.controller;

import com.example.org.bean.Exam;
import com.example.org.service.ExamService;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

@Path("exam")
public class ExamsController {
    ExamService service = new ExamService();

    @GET
    @Path("/get")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getExams(){
        List<Exam> exams = service.getAllExams();
        return Response.ok().entity(exams).build();
    }

    @GET
    @Path("/get_by_id")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getExamById(@QueryParam("id") int id){
        Exam exam = service.getExamId(id);
        return Response.ok().entity(exam).build();
    }

    @GET
    @Path("/uploaddata")
    @Produces(MediaType.TEXT_PLAIN)
    public Response uploadExam(@QueryParam("exam_name") String exam_name,
                             @QueryParam("exam_start_date") String exam_start_date,
                             @QueryParam("exam_end_date") String exam_end_date){

        ExamService service = new ExamService();
        Exam exam = new Exam();
        exam.setExam_name(exam_name);
        exam.setExam_start_date(exam_start_date);
        exam.setExam_end_date(exam_end_date);
        boolean result = service.addExam(exam);
        String n = new String("New exam created!");
        if(!result)
            n = new String("Error creating exam!");
        return Response.ok().entity(n).build();
    }

    @GET
    @Path("/delete")
    @Produces(MediaType.TEXT_PLAIN)
    public Response deleteExam(@QueryParam("id") int id){
        Exam exam = service.getExamId(id);
        boolean result = service.deleteExam(exam);
        result  = service.deleteExam(exam);
        String n = new String("Exam deleted Successfully!");
        return Response.ok().entity(n).build();
    }
}