package com.example.org.controller;

import com.example.org.bean.Evaluation;
import com.example.org.bean.Student;
import com.example.org.bean.Test;
import com.example.org.service.EvaluationService;
import com.example.org.service.StudentService;
import com.example.org.service.TestService;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.EventListener;
import java.util.List;

@Path("evaluation")
public class EvaluationController {


    EvaluationService service = new EvaluationService();

    @GET
    @Path("/uploaddata")
    @Produces(MediaType.TEXT_PLAIN)
    public Response uploadEvaluation(@QueryParam("student_id") int student_id,
                               @QueryParam("test_id") int test_id,
                               @QueryParam("responses") String responses){

        Evaluation evaluation = new Evaluation();
        evaluation.setResponses(responses);

        TestService testService = new TestService();
        Test test = testService.getTestById(test_id);

        StudentService studentService = new StudentService();
        Student student = studentService.getStudentById(student_id);
        evaluation.setStudent(student);

        evaluation.setTest(test);


        boolean result = service.addExam(evaluation);

        String s;
        if(!result) {
            s = new String("evaluation was not saved!");
        } else {
            s = new String("evaluation was saved successfully");
        }

        return Response.ok().entity(s).build();
    }

    @GET
    @Path("/get")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getEvaluations(@QueryParam("student_id") int student_id){
        List<Evaluation> tests = service.getAllExams(student_id);
        return Response.ok().entity(tests).build();
    }
}
